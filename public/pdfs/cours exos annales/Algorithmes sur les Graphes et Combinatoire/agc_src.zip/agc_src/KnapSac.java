
public class KnapSac {
    
    //static int[] values = new int[] {894, 260, 392, 281, 27};
    //static int[] weights = new int[] {8, 6, 4, 1, 10};
    //static int W = 20;

    static int[] valeurs = new int[] {3,5,8,10};
    static int[] poids = new int[] {2,3,5,6};
    static int P = 10;

    static int recknapsack(int i, int P) {
	if (i < 0) {
	    return 0;
	}
	if (poids[i] > P) {
	    return recknapsack(i-1, P);
	} else {
	    return Math.max(recknapsack(i-1, P),
			    recknapsack(i-1, P - poids[i]) + valeurs[i]);
	}
    }

    static int progdynknapsack(int n, int P, boolean affich) {

	int[][] V = new int [n+1][P+1];
	for ( int p = 0; p <= P; p++) V[0][p] = 0;
	for ( int i = 0; i <= n; i++) V[i][0] = 0;

	for ( int i = 1; i <= n; i++ ) {
	    for ( int p = 1; p <= P; p++) {
		int pi = poids[i-1];
		if ( p >= pi) {
		    int vi = valeurs[i-1];
		    System.out.println("Values: n = " + n + " P = " + P + " pi = " + pi + " vi= " + vi + " p= " + p + " i= " + i);

		    V[i][p] = Math.max(V[i-1][p], V[i-1][p-pi] + vi);
		} else {
		    V[i][p] = V[i-1][p];
		}

		System.out.println(" V = ");
		for ( int a = 0; a <= n ; a++) {
		    for ( int b = 0; b <= P ; b++) {
			System.out.print(" " + V[a][b]);
		    }
		    System.out.println(" ");
		}
	    }
	}

	if (affich) {
	    for (int o = 1 ; o <= n ; o++){
		if (V[o][P] > V[o-1][P])
		    System.out.println("L'objet " + o + " est choisi.");
		else
		    System.out.println("L'objet " + o + " n'est pas choisi.");
	    }
	}
	return V[n][P];
    }

    public static void main(String[] args) {

	int optValue = recknapsack(valeurs.length - 1, P);
	System.out.println("Optimal value for recursive = " + optValue);

	optValue = progdynknapsack(valeurs.length, P, true);
	System.out.println("Optimal value for prog dyn = " + optValue);
    }
}
