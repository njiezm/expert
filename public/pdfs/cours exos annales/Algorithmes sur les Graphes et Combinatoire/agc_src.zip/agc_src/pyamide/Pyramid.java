//
// Pyramid
// 

import java.util.List;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Iterator;
import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.lang.Math;

public class Pyramid {

    int[][] readPyramidFile (String path) {

	ArrayList<Integer> numbers = new ArrayList<>();
	int lineNb = 0;

	// Load the numbers in a list as we do not know 
	// the size of the pyramid
	Scanner input = null;
	try {
	    File pyramidFile = new File( path );
	    input = new Scanner(pyramidFile);	    
	} catch (FileNotFoundException fnfe){
	    fnfe.printStackTrace();
	}

	while (input.hasNextLine()) {
	    String line = input.nextLine();
	    String[] splitedLine = line.split("\\s+");

	   for ( String st : splitedLine ) {
		    Integer value = Integer.valueOf( st );
		    numbers.add( value );
	    }
	    numbers.add(-1);
	    lineNb++;
	}

	// Copy in the matrix
	int[][] pyramid = new int[lineNb][lineNb];
	int l = 0;
	int c = 0;
	for ( Integer n : numbers ) {
	    if ( n == -1 ) {
		l++;
		c=0;
	    } else {
		pyramid[l][c] = n;
		c++;
	    }
	}

	return pyramid;
    }

    public int findBestPathRecur(int [][] pyramid, int l, int c ){

	if ( ( c == 0 ) && ( l == 0 ) ) return pyramid[0][0];
	if ( c == 0 ) return ( findBestPathRecur( pyramid, l-1 , c ) + pyramid[l][c] );
	if ( c == l ) return ( findBestPathRecur( pyramid, l-1 , c-1 ) + pyramid[l][c] );
	return ( Math.max( findBestPathRecur( pyramid, l-1 , c-1 ),
			   findBestPathRecur( pyramid, l-1 , c ) )   + pyramid[l][c] );
    }

    public int recursiveAlgo( int [][] pyramid ){

	int bestValue = 0;
	int len = pyramid[0].length;
	for ( int c = 0 ; c < len ; c++ ){
	    int res = findBestPathRecur(pyramid, len - 1, c );
	    if ( res > bestValue) bestValue = res;
	}

	return bestValue;
    }

    public int progdynAlgo( int [][] pyramid , boolean pathDisplay ){

	int len = pyramid[0].length;
	int[][] I = new int[len][len];

	I[0][0] = pyramid[0][0];

	for ( int l = 1; l < len; l++ ){

	    I[l][0] = I[l-1][0] + pyramid[l][0];
	    I[l][l] = I[l-1][l-1] + pyramid[l][l];

	    for ( int c = 1; c < l ; c++ )
		I[l][c] = Math.max( I[l-1][c-1],  I[l-1][c] ) + pyramid[l][c];
	}

	int bestValue = 0;
	int best = 0;
	for ( int c = 0 ; c < len ; c++ )
	    if ( I[len-1][c] > bestValue ) {
		bestValue = I[len-1][c];
		best = c;
	    }
	
	// Display best path
	if (pathDisplay) {
	    System.out.print("Best path = ");
	    for ( int l = len -1 ; l > 0 ; l-- ){
		System.out.print(l + "," + best + " : " + pyramid[l][best] + " - " );
		if ( (best != 0) && (I[l-1][best-1] > I[l-1][best]) ) 
		    best = best - 1;
	    }
	    System.out.println("0,0 : " + pyramid[0][0]);
	}
	return bestValue;
    }

    public static void main(String[] args) {

	Pyramid p = new Pyramid();
	
	int[][] pyramid = p.readPyramidFile(args[0]);
	int len = pyramid[0].length;

	// Affichage de la pyramide 
	// for ( int l = 0 ; l < len ; l++) {
	//     for ( int c = 0 ; c <= l; c++) {
	// 	System.out.print( pyramid[l][c] + " ");
	//     }
	//     System.out.println(" ");
	// }

	long startTime = System.currentTimeMillis();
	int bestRecur = p.recursiveAlgo( pyramid );
	long stopTime = System.currentTimeMillis();
	
	System.out.println("Best = " + bestRecur );
	
	long elapsedTime = stopTime - startTime;
	System.out.println("Running time for recursive = " + elapsedTime);

	startTime = System.currentTimeMillis();
	int bestProgDyn = p.progdynAlgo( pyramid, false );
	stopTime = System.currentTimeMillis();
	
	System.out.println("Best = " + bestProgDyn );

	elapsedTime = stopTime - startTime;
	System.out.println("Running time for progdyn = " + elapsedTime);
    }
}
