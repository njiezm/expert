import org.jgrapht.*;
import org.jgrapht.graph.*;

import java.util.*;

class BasicGraph {

    Graph<Integer, DefaultEdge> g;
    void createGraph() {

        g = new SimpleGraph<>(DefaultEdge.class);

        // add the vertices
        g.addVertex(1);
        g.addVertex(2);
        g.addVertex(3);

        // add edges to create linking structure
        g.addEdge(1,2);
        g.addEdge(2,3);
        g.addEdge(1 , 3);
    }

    Set<Integer> getNodes() {
        return g.vertexSet();
    }

    Set<DefaultEdge> getEdgesOf( int node ) {
        return g.edgesOf( node );
    }

    List<Integer> getNeighborsOf( int node ) {
        return Graphs.neighborListOf(g, node);
    }
    void printNodes() {

        System.out.print("Node set : ");
        Set<Integer> nodes = g.vertexSet();
        Iterator<Integer> it  = nodes.iterator();
        while(it.hasNext()) {
            Integer c = it.next();
            System.out.print(" " + c);
        }
        System.out.println();
    }

    void printEdgesOf( int node) {

        System.out.print("Edges of " + node + " : ");
        Set<DefaultEdge> edges = g.edgesOf( node );
        Iterator<DefaultEdge> it  = edges.iterator();
        while(it.hasNext()) {
            DefaultEdge edge = it.next();
            System.out.print(" " + edge );
        }
        System.out.println();
    }

    void printNeighorList( int node ) {

        System.out.print("Neighbors of " + node + " : ");
        List<Integer> neighbors = Graphs.neighborListOf(g, node);
        Iterator<Integer> it = neighbors.iterator();
        while(it.hasNext()) {
            Integer n = it.next();
            System.out.print(" " + n);
        }
        System.out.println();
    }
}
public class BasicMain {

    public static void main( String args[] ) {

        DisplayGraph b = new DisplayGraph();
        b.createGraph();
    }
}
