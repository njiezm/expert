import org.jgrapht.*;
import org.jgrapht.graph.*;

import java.util.*;

class DFSGraph {
    Graph<Integer, DefaultEdge> g = new SimpleGraph<>(DefaultEdge.class);

    DFSGraph() {

        // add the vertices
        g.addVertex(1);
        g.addVertex(2);
        g.addVertex(3);
        g.addVertex(4);
        g.addVertex(5);
        g.addVertex(6);

        // add edges to create linking structure
        g.addEdge(1,2);
        g.addEdge(1,3);
        g.addEdge(2,3);
        g.addEdge(2,4);
        g.addEdge(4,5);
        g.addEdge(2,6);
    }

    Graph<Integer, DefaultEdge> getGraph() {
        return g;
    }
    Set<Integer> getNodes() {
        return g.vertexSet();
    }
    Set<DefaultEdge> getEdgesOf( int node ) {
        return g.edgesOf( node );
    }
    List<Integer> getNeighborsOf( int node ) {
        return Graphs.neighborListOf(g, node);
    }

}
class DepthFirstSearch {

    DFSGraph graph;
    HashMap<Integer,Integer> nodeColors;
    static final int BLANC = 0;
    static final int NOIR = 1;
    Set<Integer> dfsPath;

    DepthFirstSearch( DFSGraph g ) {

        graph = g;
    }

    Set<Integer> getDFSFrom( int node ) {

        // Build color table
        nodeColors = new HashMap<Integer, Integer>();
        Set<Integer> nodes = graph.getNodes();
        Iterator<Integer> it = nodes.iterator();
        while (it.hasNext()) {
            Integer c = it.next();
            nodeColors.put(c, BLANC);
        }

        // Init path
        dfsPath = new HashSet<Integer>();

        depthFirstSearch( node );

        return dfsPath;
    }

    void depthFirstSearch( int node ) {

        nodeColors.replace( node, NOIR );
        List<Integer> neighbors = Graphs.neighborListOf( graph.getGraph(), node );
        Iterator<Integer> it  = neighbors.iterator();
        while(it.hasNext()) {
            Integer c = it.next();
            if ( nodeColors.get( c ) == BLANC ) {
                dfsPath.add(c);
                depthFirstSearch(c);
            }
        }
    }
}

public class DepthFirstSearchMain {

    public static void main( String args[] ) {

        DFSGraph graph = new DFSGraph();
        DepthFirstSearch dfs = new DepthFirstSearch( graph );
        Set<Integer> dfsPath = dfs.getDFSFrom( 2 );
        System.out.println("DFS from 2 : " + dfsPath );
    }
}
