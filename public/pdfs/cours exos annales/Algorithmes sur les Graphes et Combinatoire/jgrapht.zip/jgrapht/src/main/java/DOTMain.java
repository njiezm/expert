import org.jgrapht.*;
import org.jgrapht.graph.*;
import org.jgrapht.nio.dot.*;
import org.jgrapht.util.SupplierUtil;
import static org.jgrapht.util.SupplierUtil.createIntegerSupplier;

import java.io.*;

class DOTGraph {

    static Graph<Integer, DefaultEdge> g = new SimpleGraph<>(DefaultEdge.class);

    DOTGraph() {

        // add the vertices
        g.addVertex(1);
        g.addVertex(2);
        g.addVertex(3);
        g.addVertex(4);
        g.addVertex(5);
        g.addVertex(6);

        // add edges to create linking structure
        g.addEdge(1,2);
        g.addEdge(1,3);
        g.addEdge(2,3);
        g.addEdge(2,4);
        g.addEdge(4,5);
        g.addEdge(2,6);
    }

    public static Graph<Integer,DefaultEdge> getGraph() {
        return g;
    }
}
public class DOTMain {

    public static void main( String args[] ) throws IOException {

        DOTGraph mg = new DOTGraph();
        Graph<Integer,DefaultEdge> g = DOTGraph.getGraph();
        System.out.println(g);
        String fileName = "dataOut.txt";
        File file = new File(fileName);

        // Write on file
        FileWriter fw = new FileWriter(fileName);
        DOTExporter<Integer, DefaultEdge> jexporter =
                new DOTExporter<Integer,DefaultEdge>();
        jexporter.exportGraph(g, fw);

        // Read from file
        Graph<Integer,DefaultEdge> rg = new SimpleGraph<Integer,DefaultEdge>(createIntegerSupplier(),SupplierUtil.DEFAULT_EDGE_SUPPLIER,false);;
        FileReader fr = new FileReader(fileName);
        DOTImporter<Integer, DefaultEdge> dimporter =
                new DOTImporter<Integer,DefaultEdge>();
        dimporter.importGraph(rg, fr);

        System.out.println("rg = " + rg);
    }
}
