
public class Test {

	public static void main(String[] args) {
		System.out.println("Nous allons créer 5 desserts.  Appuyez pour continuer..."); 
		LectureClavier.lireString();
		
		ComptoirDessert comptoir = new ComptoirDessert(); 
		
		Dessert pomme = new Pomme();
		pomme.setCode("1");
		comptoir.ajouterDessert(pomme);
		
		Dessert orange = new Orange();
		orange.setCode("2");
		comptoir.ajouterDessert(orange);
		
		Dessert glace = new GlaceVanille();
		glace.setCode("3");
		comptoir.ajouterDessert(glace);
		
		Dessert ile = new IleFlottante();
		ile.setCode("4");
		comptoir.ajouterDessert(ile);
		
		Dessert tarte = new TarteCitron();
		tarte.setCode("5");
		comptoir.ajouterDessert(tarte);
		
		System.out.println("Voici les desserts à vendre:");
		System.out.println(comptoir.genererRapport());
		System.out.println("Nous allons vendre 3 desserts, appuyez pour continuer...");
		LectureClavier.lireString();
		
		comptoir.vendreDessert(pomme.getCode());
		comptoir.vendreDessert(tarte.getCode());
		comptoir.vendreDessert(ile.getCode());
		
		System.out.println("Voici l'état du comptoir:");
		System.out.println(comptoir.genererRapport());
		

	}

}
