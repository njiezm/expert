
public class Orange extends ProduitFrais {
	@Override
	public String getDescription () {
		return super.getDescription() + "-ORANGE";
	}
}
