
public abstract class Dessert {
	private String code;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = this.getDescription() + "_" + code;
	}

	public abstract String getDescription ();
}
