
public abstract class Froid extends Dessert {
	public String getDescription () {
		return "FROID";
	}
}
