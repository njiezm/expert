
public class GlaceChocolat extends Gele{
	@Override
	public String getDescription () {
		return super.getDescription() + "-CHOCOLAT";
	}
}
