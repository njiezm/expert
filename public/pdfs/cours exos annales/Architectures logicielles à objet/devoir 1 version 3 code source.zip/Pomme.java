
public class Pomme extends ProduitFrais {
	@Override
	public String getDescription () {
		return super.getDescription() + "-POMME";
	}
}
