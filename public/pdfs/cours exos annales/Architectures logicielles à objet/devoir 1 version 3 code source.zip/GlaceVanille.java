
public class GlaceVanille extends Gele{
	@Override
	public String getDescription () {
		return super.getDescription() + "-VANILLE";
	}
}
