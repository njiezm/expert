
public class IleFlottante extends Froid {
	@Override
	public String getDescription () {
		return super.getDescription() + "-ILE-FLOTTANTE";
	}
}
