import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class LectureClavier {
	public static String lireString() {
		String ligne = null;
		try {
			InputStreamReader i = new InputStreamReader(System.in);
			BufferedReader b = new BufferedReader(i);
			ligne = b.readLine();
		} catch (IOException e) {
			System.err.println(e);
		}
		return ligne;
	}
}
