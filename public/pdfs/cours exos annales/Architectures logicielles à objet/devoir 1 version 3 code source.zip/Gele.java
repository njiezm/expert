
public abstract class Gele extends Dessert {
	public String getDescription () {
		return "GELE";
	}
}
