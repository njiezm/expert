
public class TarteCitron extends Froid {
	@Override
	public String getDescription () {
		return super.getDescription() + "-TARTE-CITRON";
	}
}
