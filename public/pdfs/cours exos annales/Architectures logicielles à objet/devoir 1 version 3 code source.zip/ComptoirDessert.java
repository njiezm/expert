import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class ComptoirDessert {

	private Map<String, Dessert> aVendre;
	private List<Dessert> vendus;
	
	public ComptoirDessert () {
		this.setaVendre(new HashMap<String, Dessert>());
		this.setVendus(new ArrayList<Dessert>());
	}
	
	public Map<String, Dessert> getaVendre() {
		return aVendre;
	}
	public void setaVendre(Map<String, Dessert> aVendre) {
		this.aVendre = aVendre;
	}
	public List<Dessert> getVendus() {
		return vendus;
	}
	public void setVendus(List<Dessert> vendus) {
		this.vendus = vendus;
	}
	
	public void ajouterDessert (Dessert dessert) {
		this.getaVendre().put(dessert.getCode(), dessert);
	}
	public List<String> getAllCodes () {
		List<String> codes = new ArrayList<String>();
		for (Entry<String, Dessert> entry : this.getaVendre().entrySet()) {
			codes.add(entry.getKey());
		}
		return codes;
	}
	public void vendreDessert (String code) {
		Dessert dessert = this.getaVendre().get(code);
		if (dessert != null) {
			this.getaVendre().remove(code);
			this.getVendus().add(dessert);
		}
	}
	
	public String genererRapport () {
		StringBuilder sb = new StringBuilder();
		sb.append ("Dessert à vendre:\n");
		for (Entry<String, Dessert> entry : this.getaVendre().entrySet()) {
			sb.append(" - " + entry.getValue().getCode() + "\n");
		}
		sb.append ("Dessert vendus:\n");
		for (Dessert dessert : this.getVendus()) {
			sb.append(" - " + dessert.getCode() + "\n");
		}
		
		return sb.toString();
	}
	
}
