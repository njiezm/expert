
public abstract class ProduitFrais extends Dessert {
	public String getDescription () {
		return "FRAIS";
	}
}
