public class BouleGlace implements ElementCornet {
    private String parfum;
    private double prix;

    public BouleGlace(String parfum, double prix) {
        this.parfum = parfum;
        this.prix = prix;
    }

    @Override
    public String getNom() { return "Boule Glace " + parfum; }
    
    @Override
    public double getPrix() { return prix; }
}
