public class Gateau extends DessertLacte {
    private String parfum;

    public Gateau(String parfum, double prix) {
        super("Gâteau " + parfum, prix, false);
        this.parfum = parfum;
    }

    @Override
    public String getDescription() {
        return "Gâteau moelleux au " + this.parfum + ". " + super.getDescription();
    }
}
