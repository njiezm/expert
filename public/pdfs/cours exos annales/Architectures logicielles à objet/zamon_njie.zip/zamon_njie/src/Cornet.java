import java.util.ArrayList;
import java.util.List;

public class Cornet implements ElementCornet {
    private List<ElementCornet> elements = new ArrayList<>();
    private final double PRIX_BASE_CORNET = 0.50;
    private final String TYPE_CORNET = "Cornet Croustillant";

    public void ajouter(ElementCornet element) {
        elements.add(element);
    }

    @Override
    public double getPrix() {
        double prixTotal = PRIX_BASE_CORNET;
        for (ElementCornet element : elements) {
            prixTotal += element.getPrix();
        }
        return prixTotal;
    }

    @Override
    public String getNom() {
        StringBuilder sb = new StringBuilder(TYPE_CORNET + " contenant : ");
        for (ElementCornet element : elements) {
            sb.append(element.getNom()).append(" | ");
        }
        return sb.toString();
    }
}
