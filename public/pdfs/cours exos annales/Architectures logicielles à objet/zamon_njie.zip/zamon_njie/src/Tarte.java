public class Tarte implements Dessert {
    private String fruit;
    private double prix;

    public Tarte(String fruit, double prix) {
        this.fruit = fruit;
        this.prix = prix;
    }
    
    @Override
    public String getNom() { return "Tarte aux " + this.fruit; }
    
    @Override
    public double getPrix() { return this.prix; }
    
    @Override
    public String getDescription() {
        return "Délicieuse tarte croustillante aux " + this.fruit + ".";
    }
}
