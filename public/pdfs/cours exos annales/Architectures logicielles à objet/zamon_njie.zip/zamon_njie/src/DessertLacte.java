public abstract class DessertLacte implements Dessert {
    protected String nom;
    protected double prix;
    protected boolean estFrais;

    public DessertLacte(String nom, double prix, boolean estFrais) {
        this.nom = nom;
        this.prix = prix;
        this.estFrais = estFrais;
    }
    
    @Override
    public String getNom() { return nom; }
    
    @Override
    public double getPrix() { return prix; }
    
    @Override
    public String getDescription() {
        return "Dessert laitier, à consommer " + (estFrais ? "très frais." : "tempéré.");
    }
}
