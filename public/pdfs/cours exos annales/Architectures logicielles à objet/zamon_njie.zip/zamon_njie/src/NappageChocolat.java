public class NappageChocolat extends AjoutDecorateur {
    private final double COUT_NAPPAGE = 0.50;
    private final String NOM_NAPPAGE = " + Nappage Chocolat (0.50 EUR)";

    public NappageChocolat(ElementCornet elementDecore) {
        super(elementDecore);
    }

    @Override
    public String getNom() {
        return super.getNom() + NOM_NAPPAGE;
    }

    @Override
    public double getPrix() {
        return super.getPrix() + COUT_NAPPAGE;
    }
}
