public interface Dessert {
    String getNom();
    double getPrix();
    String getDescription(); 
}
