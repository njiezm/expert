public interface ElementCornet {
    String getNom();
    double getPrix();
}
