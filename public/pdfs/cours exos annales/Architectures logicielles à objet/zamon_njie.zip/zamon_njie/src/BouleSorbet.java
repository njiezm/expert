public class BouleSorbet implements ElementCornet {
    private String parfum;
    private double prix;

    public BouleSorbet(String parfum, double prix) {
        this.parfum = parfum;
        this.prix = prix;
    }

    @Override
    public String getNom() { return "Boule Sorbet " + parfum; }
    
    @Override
    public double getPrix() { return prix; }
}
