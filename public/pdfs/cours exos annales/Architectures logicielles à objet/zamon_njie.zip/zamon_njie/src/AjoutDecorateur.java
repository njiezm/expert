public abstract class AjoutDecorateur implements ElementCornet {
    protected ElementCornet elementDecore;

    public AjoutDecorateur(ElementCornet elementDecore) {
        this.elementDecore = elementDecore;
    }

    @Override
    public String getNom() {
        return elementDecore.getNom();
    }

    @Override
    public double getPrix() {
        return elementDecore.getPrix();
    }
}
