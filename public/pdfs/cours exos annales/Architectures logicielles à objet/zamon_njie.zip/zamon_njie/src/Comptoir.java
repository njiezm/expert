import java.util.ArrayList;
import java.util.List;

public class Comptoir {
    private List<Dessert> stock;
    private int dessertsAjoutes;
    private int dessertsVendus;

    public Comptoir() {
        this.stock = new ArrayList<>();
        this.dessertsAjoutes = 0;
        this.dessertsVendus = 0;
    }

    public void ajouterDessert(Dessert dessert) {
        this.stock.add(dessert);
        this.dessertsAjoutes++;
    }

    public Dessert vendreDessert(String nom) {
        for (int i = 0; i < stock.size(); i++) {
            if (stock.get(i).getNom().equalsIgnoreCase(nom)) {
                Dessert vendu = stock.remove(i);
                this.dessertsVendus++;
                return vendu;
            }
        }
        return null; // Dessert non trouvé
    }

    public String obtenirRapport() {
        return "\n--- Bilan de la Journée ---\n" +
               this.dessertsAjoutes + " desserts ajoutés\n" +
               this.dessertsVendus + " desserts vendus\n" +
               "Stock restant : " + this.stock.size() + " desserts";
    }
}
