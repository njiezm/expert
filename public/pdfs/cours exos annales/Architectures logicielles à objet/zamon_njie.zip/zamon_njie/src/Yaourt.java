public class Yaourt extends DessertLacte {
    private String fruit;

    public Yaourt(String fruit, double prix) {
        super("Yaourt " + fruit, prix, true);
        this.fruit = fruit;
    }

    @Override
    public String getDescription() {
        return "Yaourt nature avec " + this.fruit + ". " + super.getDescription();
    }
}
