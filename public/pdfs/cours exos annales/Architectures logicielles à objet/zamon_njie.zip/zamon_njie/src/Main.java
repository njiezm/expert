public class Main {
    public static void main(String[] args) {
        
        System.out.println("==================================================");
        System.out.println("           PARTIE 1 : GESTION DU COMPTOIR");
        System.out.println("==================================================");
        
        Comptoir comptoir = new Comptoir();

        Dessert tartePomme = new Tarte("Pommes", 3.50); 
        Dessert yaourtVanille = new Yaourt("Vanille", 1.80);
        Dessert gateauChoco = new Gateau("Chocolat", 4.20);
        
        System.out.println("--- Initialisation du stock ---");
        comptoir.ajouterDessert(tartePomme);
        comptoir.ajouterDessert(yaourtVanille);
        comptoir.ajouterDessert(gateauChoco);
        
        System.out.println("\n--- Détails de vente ---");
        Dessert vendu1 = comptoir.vendreDessert("Yaourt Vanille");
        if (vendu1 != null) {
            System.out.println("Vente réussie : " + vendu1.getNom());
        }
        
        System.out.println(comptoir.obtenirRapport());

        System.out.println("\n==================================================");
        System.out.println("      PARTIES 2 & 3 : COMPOSITE ET DÉCORATEUR");
        System.out.println("==================================================");

        Cornet monCornet = new Cornet();
        BouleGlace bouleVanille = new BouleGlace("Vanille", 2.00);
        monCornet.ajouter(bouleVanille);
        
        System.out.println("--- Cornet de Base (Composite) ---");
        System.out.printf("Prix de base : %.2f euros\n", monCornet.getPrix());

        ElementCornet cornetDecore = new NappageChocolat(monCornet); 
        cornetDecore = new Chantilly(cornetDecore);                  
        
        System.out.println("\n--- Cornet Décoré (Décorateur) ---");
        System.out.println("Composition finale : " + cornetDecore.getNom());
        System.out.printf("Prix Total Final : %.2f euros\n", cornetDecore.getPrix());
    }
}
