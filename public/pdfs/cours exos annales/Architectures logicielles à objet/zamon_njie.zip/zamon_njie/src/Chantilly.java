public class Chantilly extends AjoutDecorateur {
    private final double COUT_CHANTILLY = 0.80;
    private final String NOM_CHANTILLY = " + Chantilly (0.80 EUR)";

    public Chantilly(ElementCornet elementDecore) {
        super(elementDecore);
    }

    @Override
    public String getNom() {
        return super.getNom() + NOM_CHANTILLY;
    }

    @Override
    public double getPrix() {
        return super.getPrix() + COUT_CHANTILLY;
    }
}
